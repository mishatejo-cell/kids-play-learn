import logging, os
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup, WebAppInfo
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, ContextTypes, filters

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN", "").strip()
WEBAPP_URL = os.getenv("WEBAPP_URL", "").strip()
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logging.getLogger("httpx").setLevel(logging.WARNING)

T = {
 "ka":{"welcome":"გამარჯობა! 🌈 კეთილი იყოს შენი მობრძანება თამაშისა და სწავლის სამყაროში.","choose":"აირჩიე ენა / Выбери язык / Choose a language:","play":"🎮 თამაში","language":"🌐 ენა","parent":"👨‍👩‍👧 მშობლისთვის","help":"თამაშები განკუთვნილია 3–5 წლის ბავშვებისთვის. არ გააზიარო პირადი ინფორმაცია.","parent_text":"მშობლისთვის: MVP არ ითხოვს ბავშვის პირად მონაცემებს. პროგრესი ინახება მოწყობილობაზე. საჯარო გაშვებამდე შეამოწმეთ კონფიდენციალურობის პოლიტიკა და ადგილობრივი კანონები."},
 "ru":{"welcome":"Привет! 🌈 Добро пожаловать в мир игр и обучения.","choose":"Выбери язык / აირჩიე ენა / Choose a language:","play":"🎮 Играть","language":"🌐 Язык","parent":"👨‍👩‍👧 Родителям","help":"Игры предназначены для детей 3–5 лет. Не сообщай личную информацию.","parent_text":"Для родителей: MVP не запрашивает личные данные ребёнка. Прогресс хранится на устройстве. Перед публичным запуском проверьте политику конфиденциальности и местные требования."},
 "en":{"welcome":"Hello! 🌈 Welcome to the world of play and learning.","choose":"Choose a language / აირჩიე ენა / Выбери язык:","play":"🎮 Play","language":"🌐 Language","parent":"👨‍👩‍👧 For parents","help":"Games are designed for children ages 3–5. Never share personal information.","parent_text":"For parents: this MVP does not request a child's personal data. Progress is stored on the device. Review privacy and local requirements before public launch."}
}
NAMES={"ka":"ქართული 🇬🇪","ru":"Русский 🇷🇺","en":"English 🇬🇧"}
def lang(ctx): return ctx.user_data.get("lang","ka")
def kb(l):
 t=T[l]
 return ReplyKeyboardMarkup([[KeyboardButton(t["play"],web_app=WebAppInfo(url=WEBAPP_URL))],[KeyboardButton(t["language"]),KeyboardButton(t["parent"])]],resize_keyboard=True,is_persistent=True)
async def start(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
 l=lang(ctx)
 await update.message.reply_text(T[l]["welcome"],reply_markup=kb(l))
 await update.message.reply_text(T[l]["choose"],reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(NAMES[x],callback_data=f"lang:{x}") for x in ("ka","ru","en")]]))
async def choose(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
 await update.message.reply_text("აირჩიე ენა / Выбери язык / Choose a language:",reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(NAMES[x],callback_data=f"lang:{x}") for x in ("ka","ru","en")]]))
async def language_cb(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
 q=update.callback_query; await q.answer()
 l=q.data.split(":")[1]; ctx.user_data["lang"]=l
 await q.edit_message_text(T[l]["welcome"])
 await q.message.reply_text(T[l]["choose"],reply_markup=kb(l))
async def help_cmd(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
 l=lang(ctx); await update.message.reply_text(T[l]["help"],reply_markup=kb(l))
async def messages(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
 l=lang(ctx); s=update.message.text or ""; t=T[l]
 if s in (t["language"],"/language"): await choose(update,ctx)
 elif s==t["parent"]: await update.message.reply_text(t["parent_text"],reply_markup=kb(l))
 elif s==t["play"]: await update.message.reply_text(t["welcome"],reply_markup=kb(l))
 else: await update.message.reply_text(t["help"],reply_markup=kb(l))
def main():
 if not TOKEN: raise SystemExit("BOT_TOKEN missing. Copy .env.example to .env and add your BotFather token.")
 if not WEBAPP_URL.startswith("https://"): raise SystemExit("WEBAPP_URL must be a public HTTPS URL.")
 app=Application.builder().token(TOKEN).build()
 app.add_handler(CommandHandler("start",start)); app.add_handler(CommandHandler("language",choose)); app.add_handler(CommandHandler("help",help_cmd))
 app.add_handler(CallbackQueryHandler(language_cb,pattern=r"^lang:(ka|ru|en)$"))
 app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,messages))
 app.run_polling(allowed_updates=Update.ALL_TYPES)
if __name__=="__main__": main()
